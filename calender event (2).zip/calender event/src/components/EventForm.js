import React, { useState, useEffect } from 'react';

const recurrenceOptions = [
  { value: 'none', label: 'None' },
  { value: 'daily', label: 'Daily' },
  { value: 'weekly', label: 'Weekly' },
  { value: 'monthly', label: 'Monthly' },
  { value: 'custom', label: 'Custom' },
];

const defaultEvent = {
  title: '',
  date: '',
  time: '12:00',
  description: '',
  recurrence: 'none',
  recurrenceInterval: 1,
  recurrenceDays: [],
  color: '#3174ad',
};

const EventForm = ({ eventData, onSave, onDelete, onCancel }) => {
  const [event, setEvent] = useState(eventData || defaultEvent);

  useEffect(() => {
    if (eventData) {
      setEvent(eventData);
    }
  }, [eventData]);

  const handleChange = e => {
    const { name, value, type, checked } = e.target;
    if (name === 'recurrenceDays') {
      let newDays = [...event.recurrenceDays];
      if (checked) {
        newDays.push(value);
      } else {
        newDays = newDays.filter(day => day !== value);
      }
      setEvent(prev => ({ ...prev, recurrenceDays: newDays }));
    } else if (type === 'number') {
      setEvent(prev => ({ ...prev, [name]: parseInt(value) }));
    } else {
      setEvent(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = e => {
    e.preventDefault();
    onSave(event);
  };

  return (
    <div className="event-form-overlay" style={{
      position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
      backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex',
      justifyContent: 'center', alignItems: 'center', zIndex: 1000
    }}>
      <form onSubmit={handleSubmit} style={{
        backgroundColor: 'white', padding: '20px', borderRadius: '8px',
        width: '320px', maxHeight: '90vh', overflowY: 'auto'
      }}>
        <h3>{event.id ? 'Edit Event' : 'Add Event'}</h3>
        <div>
          <label>Title:</label>
          <input
            type="text"
            name="title"
            value={event.title}
            onChange={handleChange}
            required
            style={{ width: '100%' }}
          />
        </div>
        <div>
          <label>Date:</label>
          <input
            type="date"
            name="date"
            value={event.date}
            onChange={handleChange}
            required
            style={{ width: '100%' }}
          />
        </div>
        <div>
          <label>Time:</label>
          <input
            type="time"
            name="time"
            value={event.time}
            onChange={handleChange}
            required
            style={{ width: '100%' }}
          />
        </div>
        <div>
          <label>Description:</label>
          <textarea
            name="description"
            value={event.description}
            onChange={handleChange}
            style={{ width: '100%' }}
          />
        </div>
        <div>
          <label>Recurrence:</label>
          <select name="recurrence" value={event.recurrence} onChange={handleChange} style={{ width: '100%' }}>
            {recurrenceOptions.map(opt => (
              <option key={opt.value} value={opt.value}>{opt.label}</option>
            ))}
          </select>
        </div>
        {event.recurrence === 'weekly' && (
          <div>
            <label>Repeat on:</label>
            <div style={{ display: 'flex', flexWrap: 'wrap' }}>
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                <label key={day} style={{ marginRight: '8px' }}>
                  <input
                    type="checkbox"
                    name="recurrenceDays"
                    value={day}
                    checked={event.recurrenceDays.includes(day)}
                    onChange={handleChange}
                  />
                  {day}
                </label>
              ))}
            </div>
          </div>
        )}
        {event.recurrence === 'custom' && (
          <div>
            <label>Repeat every (days):</label>
            <input
              type="number"
              name="recurrenceInterval"
              min="1"
              value={event.recurrenceInterval}
              onChange={handleChange}
              style={{ width: '100%' }}
            />
          </div>
        )}
        <div>
          <label>Event Color:</label>
          <input
            type="color"
            name="color"
            value={event.color}
            onChange={handleChange}
            style={{ width: '100%', height: '30px', padding: 0, border: 'none' }}
          />
        </div>
        <div style={{ marginTop: '10px', display: 'flex', justifyContent: 'space-between' }}>
          <button type="submit">Save</button>
          {event.id && <button type="button" onClick={() => onDelete(event.id)} style={{ backgroundColor: 'red', color: 'white' }}>Delete</button>}
          <button type="button" onClick={onCancel}>Cancel</button>
        </div>
      </form>
    </div>
  );
};

export default EventForm;
