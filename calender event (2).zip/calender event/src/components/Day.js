import React from 'react';

const Day = ({ day, isCurrentMonth, isToday, events, onDayClick, onEventClick }) => {
  return (
    <div
      className={`day-cell ${isCurrentMonth ? '' : 'not-current-month'} ${isToday ? 'today' : ''}`}
      onClick={() => onDayClick(day)}
      style={{ position: 'relative', minHeight: '80px', border: '1px solid #ddd', padding: '4px', cursor: 'pointer' }}
    >
      <div style={{ fontWeight: 'bold', marginBottom: '4px' }}>{day.getDate()}</div>
      <div style={{ overflowY: 'auto', maxHeight: '60px' }}>
        {events.map(event => (
          <div
            key={event.id}
            onClick={e => {
              e.stopPropagation();
              onEventClick(event);
            }}
            style={{
              backgroundColor: event.color || '#3174ad',
              color: 'white',
              padding: '2px 4px',
              borderRadius: '4px',
              marginBottom: '2px',
              fontSize: '12px',
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              cursor: 'pointer',
            }}
            title={event.title}
            draggable
            onDragStart={e => {
              e.dataTransfer.setData('text/plain', event.id);
            }}
          >
            {event.title}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Day;
