import React from 'react';

const EventList = ({ events, onEdit, onDelete }) => {
  if (!events.length) {
    return <div>No events found.</div>;
  }

  return (
    <div style={{ maxHeight: '200px', overflowY: 'auto', marginTop: '10px' }}>
      {events.map(event => (
        <div key={event.id} style={{ borderBottom: '1px solid #ccc', padding: '8px 0' }}>
          <div>
            <strong>{event.title}</strong> - {event.date} {event.time}
          </div>
          <div>{event.description}</div>
          <div style={{ marginTop: '4px' }}>
            <button onClick={() => onEdit(event)} style={{ marginRight: '8px' }}>Edit</button>
            <button onClick={() => onDelete(event.id)} style={{ backgroundColor: 'red', color: 'white' }}>Delete</button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default EventList;
