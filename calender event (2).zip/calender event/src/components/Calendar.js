import React, { useState, useEffect } from 'react';
import { getMonthDays, isToday, isSameDay, formatDate, addMonth, subMonth, parseDate } from '../utils/dateUtils';
import Day from './Day';
import EventForm from './EventForm';
import EventList from './EventList';

const Calendar = () => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDay, setSelectedDay] = useState(null);
  const [events, setEvents] = useState([]);
  const [editingEvent, setEditingEvent] = useState(null);
  const [draggedEventId, setDraggedEventId] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const storedEvents = localStorage.getItem('calendarEvents');
    if (storedEvents) {
      setEvents(JSON.parse(storedEvents));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('calendarEvents', JSON.stringify(events));
  }, [events]);

  const days = getMonthDays(currentDate);

  const eventsForDay = day => {
    const dayStr = formatDate(day);
    return events.filter(event => {
      if (searchQuery) {
        const lowerQuery = searchQuery.toLowerCase();
        if (!event.title.toLowerCase().includes(lowerQuery) && !event.description.toLowerCase().includes(lowerQuery)) {
          return false;
        }
      }
      if (event.recurrence === 'none') {
        return event.date === dayStr;
      } else {
        return isEventOnDay(event, day);
      }
    });
  };

  const isEventOnDay = (event, day) => {
    const eventDate = parseDate(event.date);
    if (event.recurrence === 'daily') {
      return day >= eventDate;
    }
    if (event.recurrence === 'weekly') {
      if (day < eventDate) return false;
      const dayName = day.toLocaleDateString('en-US', { weekday: 'short' });
      return event.recurrenceDays.includes(dayName);
    }
    if (event.recurrence === 'monthly') {
      if (day < eventDate) return false;
      return day.getDate() === eventDate.getDate();
    }
    if (event.recurrence === 'custom') {
      if (day < eventDate) return false;
      const diffDays = Math.floor((day - eventDate) / (1000 * 60 * 60 * 24));
      return diffDays % event.recurrenceInterval === 0;
    }
    return false;
  };

  const handleDayClick = day => {
    setSelectedDay(day);
    setEditingEvent(null);
  };

  const handleEventClick = event => {
    setEditingEvent(event);
    setSelectedDay(null);
  };

  const handleSaveEvent = event => {
    if (event.id) {
      setEvents(prev => prev.map(ev => (ev.id === event.id ? event : ev)));
    } else {
      event.id = Date.now().toString();
      setEvents(prev => [...prev, event]);
    }
    setSelectedDay(null);
    setEditingEvent(null);
  };

  const handleDeleteEvent = id => {
    setEvents(prev => prev.filter(ev => ev.id !== id));
    setEditingEvent(null);
  };

  const handleCancel = () => {
    setSelectedDay(null);
    setEditingEvent(null);
  };

  const handlePrevMonth = () => {
    setCurrentDate(subMonth(currentDate));
  };

  const handleNextMonth = () => {
    setCurrentDate(addMonth(currentDate));
  };

  const handleDragStart = (e, eventId) => {
    setDraggedEventId(eventId);
  };

  const handleDrop = (e, day) => {
    e.preventDefault();
    if (!draggedEventId) return;
    const event = events.find(ev => ev.id === draggedEventId);
    if (!event) return;

    
    const newDateStr = formatDate(day);
    const conflict = events.some(ev => ev.id !== event.id && ev.date === newDateStr && ev.time === event.time);
    if (conflict) {
      alert('Event conflict detected. Cannot move event to this date and time.');
      setDraggedEventId(null);
      return;
    }

    const updatedEvent = { ...event, date: newDateStr };
    setEvents(prev => prev.map(ev => (ev.id === event.id ? updatedEvent : ev)));
    setDraggedEventId(null);
  };

  const allowDrop = e => {
    e.preventDefault();
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
        <button onClick={handlePrevMonth}>Previous</button>
        <h2>{currentDate.toLocaleString('default', { month: 'long', year: 'numeric' })}</h2>
        <button onClick={handleNextMonth}>Next</button>
      </div>
      <div style={{ marginBottom: '10px' }}>
        <input
          type="text"
          placeholder="Search events..."
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          style={{ width: '100%', padding: '8px', fontSize: '16px' }}
        />
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: '2px' }}>
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(dayName => (
          <div key={dayName} style={{ fontWeight: 'bold', textAlign: 'center' }}>{dayName}</div>
        ))}
        {days.map(day => (
          <div
            key={day.toISOString()}
            onDrop={e => handleDrop(e, day)}
            onDragOver={allowDrop}
          >
            <Day
              day={day}
              isCurrentMonth={day.getMonth() === currentDate.getMonth()}
              isToday={isToday(day)}
              events={eventsForDay(day)}
              onDayClick={handleDayClick}
              onEventClick={handleEventClick}
              onDragStart={handleDragStart}
            />
          </div>
        ))}
      </div>
      {(selectedDay || editingEvent) && (
        <EventForm
          eventData={editingEvent || { ...{ date: formatDate(selectedDay), time: '12:00', recurrence: 'none', recurrenceDays: [], recurrenceInterval: 1, color: '#3174ad' } }}
          onSave={handleSaveEvent}
          onDelete={handleDeleteEvent}
          onCancel={handleCancel}
        />
      )}
      <div style={{ marginTop: '20px' }}>
        <h3>All Events</h3>
        <EventList events={events} onEdit={setEditingEvent} onDelete={handleDeleteEvent} />
      </div>
    </div>
  );
};

export default Calendar;
