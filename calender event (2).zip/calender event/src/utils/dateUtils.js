import { startOfMonth, endOfMonth, startOfWeek, endOfWeek, addDays, format, isSameMonth, isSameDay, addMonths, subMonths, parseISO } from 'date-fns';

export function getMonthDays(date) {
  const startMonth = startOfMonth(date);
  const endMonth = endOfMonth(date);
  const startDate = startOfWeek(startMonth);
  const endDate = endOfWeek(endMonth);

  const days = [];
  let day = startDate;
  while (day <= endDate) {
    days.push(day);
    day = addDays(day, 1);
  }
  return days;
}

export function formatDate(date, dateFormat = 'yyyy-MM-dd') {
  return format(date, dateFormat);
}

export function isToday(date) {
  return isSameDay(date, new Date());
}

export function addMonth(date) {
  return addMonths(date, 1);
}

export function subMonth(date) {
  return subMonths(date, 1);
}

export function parseDate(dateString) {
  return parseISO(dateString);
}
